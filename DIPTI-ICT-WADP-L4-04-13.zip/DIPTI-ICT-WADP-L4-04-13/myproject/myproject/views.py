from django.shortcuts import redirect,render
from myapp.models import *

def homepage(request):

    book_list=booklist.objects.all()
    book={
        'books':book_list
    }
    return render(request,'index.html',book)


def book_view(request):
    book_list=booklist.objects.all()
    books={
        'books':book_list
    }
    return render(request,'book_view.html',books)


def add_book(request):
     if request.method=='POST':
      Book_Name=request.POST.get('bookName')
      Author_Name=request.POST.get('authorName')
      Publication_Date=request.POST.get('publicationDate')
      Genre=request.POST.get('genre')
      Photo=request.FILES.get('bookCover')
      book_disp=request.POST.get('desperation')
      addbook=booklist(
        book_name=Book_Name,
        book_author=Author_Name,
        book_genre=Genre,
        book_image=Photo,
        book_publisher=Publication_Date,
        book_disp=book_disp

            
               )
      addbook.save()
      return redirect("add_book")

     return render(request,'add_book.html')


def deletepage(request,id):
   data=booklist.objects.get(id=id)
   data.delete()
   return redirect("homepage")

def view_page(request,id):
   data=booklist.objects.get(id=id)
   books_view={
    "booksview":book_view
   }
   return redirect(request,"book_view.html",books_view)