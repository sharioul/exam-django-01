from django.contrib import admin
from django.urls import path
from myproject.views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('homepage', homepage,name="homepage"),
    path('book_view', book_view,name="book_view"),
    path('add_book', add_book,name="add_book"),
    path("deletepage/<str:id>", deletepage, name='deletepage'),
    path("view_page/<str:id>", view_page, name='view_page'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
