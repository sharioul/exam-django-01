from django.db import models

# Create your models here.
class booklist(models.Model):
   book_name=models.CharField( max_length=100,null=True)
   book_author=models.CharField(max_length=100,null=True)
   book_image=models.ImageField(upload_to='book_image',null=True)
   book_genre=models.CharField(max_length=50,null=True)
   book_publisher=models.DateTimeField(auto_now=False, auto_now_add=False,null=True)
   book_disp=models.CharField(max_length=1000,null=True)